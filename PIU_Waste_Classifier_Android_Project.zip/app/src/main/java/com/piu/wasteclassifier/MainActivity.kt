package com.piu.wasteclassifier

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MainActivity : Activity() {
    private val classes = arrayOf("Batteries", "Clothes/Textiles", "E-waste", "Glass", "Light Bulbs", "Metal", "Organic", "Paper", "Plastic")
    private var interpreter: Interpreter? = null
    private lateinit var preview: ImageView
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val model = assets.open("waste_classifier.tflite").readBytes()
            val buffer = ByteBuffer.allocateDirect(model.size).order(ByteOrder.nativeOrder())
            buffer.put(model)
            buffer.rewind()
            interpreter = Interpreter(buffer)
        } catch (_: Exception) { }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        val heading = TextView(this).apply {
            text = "PIU Waste Classifier"
            textSize = 26f
        }
        preview = ImageView(this).apply {
            adjustViewBounds = true
            minimumHeight = 350
        }
        val choose = Button(this).apply {
            text = "Choose Waste Image"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
                startActivityForResult(intent, 100)
            }
        }
        result = TextView(this).apply {
            text = "Select an image to classify."
            textSize = 18f
            setPadding(0, 24, 0, 0)
        }
        layout.addView(heading)
        layout.addView(choose)
        layout.addView(preview)
        layout.addView(result)
        setContentView(layout)
        if (interpreter == null) result.text = "Model file missing. Add waste_classifier.tflite to app/src/main/assets to enable AI classification."
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val bitmap = loadBitmap(uri)
            preview.setImageBitmap(bitmap)
            classify(bitmap)
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap {
        return if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { decoder, _, _ ->
                decoder.isMutableRequired = true
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(contentResolver, uri)
        }
    }

    private fun classify(bitmap: Bitmap) {
        val tflite = interpreter
        if (tflite == null) {
            result.text = "Image selected. AI model is not installed yet."
            return
        }
        try {
            val scaled = Bitmap.createScaledBitmap(bitmap, 224, 224, true)
            val input = ByteBuffer.allocateDirect(1 * 224 * 224 * 3 * 4).order(ByteOrder.nativeOrder())
            for (y in 0 until 224) for (x in 0 until 224) {
                val pixel = scaled.getPixel(x, y)
                input.putFloat(((pixel shr 16) and 0xFF) / 255f)
                input.putFloat(((pixel shr 8) and 0xFF) / 255f)
                input.putFloat((pixel and 0xFF) / 255f)
            }
            val output = Array(1) { FloatArray(classes.size) }
            tflite.run(input, output)
            val best = output[0].indices.maxByOrNull { output[0][it] } ?: 0
            result.text = "Prediction: ${classes[best]}\nConfidence: ${"%.1f".format(output[0][best] * 100)}%"
        } catch (e: Exception) {
            result.text = "Could not classify this image: ${e.message}"
        }
    }
}
