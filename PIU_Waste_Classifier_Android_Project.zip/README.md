# PIU Waste Classifier Android App

This is a starter Android project for the PIU Waste Classifier.

## Build
Run `gradle assembleDebug` from the project root using JDK 17 and Gradle 8.9.

## Add the trained model
Put your TensorFlow Lite model at:
`app/src/main/assets/waste_classifier.tflite`

Expected model input: float32 `[1,224,224,3]`, RGB normalized to 0..1.
Expected output: float32 `[1,9]`.

Class order: Batteries, Clothes/Textiles, E-waste, Glass, Light Bulbs, Metal, Organic, Paper, Plastic.

**Important:** The uploaded APP.py is a Windows Tkinter desktop app. This Android project is a mobile starter app, not a direct conversion of that Python file. Actual AI classification requires the trained `.tflite` model.
